import pytest
from utils.extract import scrape_fashion

def test_scrape_fashion_success():
    """Menguji kesuksesan ekstraksi data asli langsung dari server sandbox Dicoding"""
    base_url = "https://fashion-studio.dicoding.dev/"

    result = scrape_fashion(base_url)

    assert isinstance(result, list), "Output dari fungsi scrape_fashion harus berupa List"
    assert len(result) > 0, "Fungsi gagal mengumpulkan data (List kosong)"
    assert len(result) == 1000, "Jumlah total produk yang dikumpulkan dari 50 halaman harus tepat 1000"

    first_product = result[0]
    assert "Title" in first_product, "Setiap produk harus memiliki kunci 'Title'"
    assert "Price" in first_product, "Setiap produk harus memiliki kunci 'Price'"
    assert "Rating" in first_product, "Setiap produk harus memiliki kunci 'Rating'"