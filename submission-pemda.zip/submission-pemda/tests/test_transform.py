import pytest
import pandas as pd
from utils.transform import clean_data

def test_clean_data():
    mock_raw = [
        {"Title": "Kaos Keren", "Price": "$10.00", "Rating": "⭐ 4.5 / 5", "Colors": "3 Colors", "Size": "Size: M", "Gender": "Gender: Men"},
        {"Title": "Unknown Product", "Price": "$12.00", "Rating": "⭐ 4.0 / 5", "Colors": "1 Color", "Size": "Size: L", "Gender": "Gender: Women"},
        {"Title": "Hoodie Bad", "Price": "Price Unavailable", "Rating": "Invalid Rating", "Colors": "2 Colors", "Size": "Size: XL", "Gender": "Gender: Unisex"}
    ]
    
    df_clean = clean_data(mock_raw)
    
    assert len(df_clean) == 1
    assert df_clean['Title'].iloc[0] == "Kaos Keren"
    
    assert df_clean['Price'].iloc[0] == 160000.0  # $10.00 * 16000
    assert df_clean['Rating'].iloc[0] == 4.5
    assert df_clean['Colors'].iloc[0] == 3
    assert df_clean['Size'].iloc[0] == "M"
    assert df_clean['Gender'].iloc[0] == "Men"
    assert 'Timestamp' in df_clean.columns, "Kolom 'Timestamp' harus ada di dalam DataFrame hasil transformasi!"