# tests/test_load.py
import pytest
import pandas as pd
from unittest.mock import patch, MagicMock, mock_open
from utils.load import load_data

@patch("utils.load.create_engine")
@patch("utils.load.gspread.authorize")
@patch("utils.load.ServiceAccountCredentials.from_json_keyfile_dict")
@patch("os.path.exists", return_value=True)
def test_load_data_calls_repositories(mock_exists, mock_creds, mock_gspread, mock_engine):
    """Menguji kesuksesan fungsi load ke CSV, Google Sheets, dan PostgreSQL"""

    mock_df = pd.DataFrame([{
        "Title": "Kemeja", 
        "Price": 150000.0, 
        "Rating": 4.5, 
        "Colors": 3, 
        "Size": "M", 
        "Gender": "Men"
    }])
    mock_json_content = '{"type": "service_account"}'

    mock_client = MagicMock()
    mock_spreadsheet = MagicMock()
    mock_sheet = MagicMock()
    
    mock_gspread.return_value = mock_client
    mock_client.open_by_key.return_value = mock_spreadsheet
    mock_spreadsheet.sheet1 = mock_sheet

    with patch("builtins.open", mock_open(read_data=mock_json_content)):
        result = load_data(
            df=mock_df, 
            spreadsheet_url="https://docs.google.com/spreadsheets/d/1k9bYcZlgDkwpyZ1USNwzNpBlER3hd_BRNHC4fEisCh0/edit", 
            db_url="postgresql+psycopg2://localhost:5432/test"
        )

    assert result is True, "Fungsi load_data harus mengembalikan True saat sukses"

    mock_sheet.clear.assert_called_once()

    mock_sheet.update.assert_called_once()

    mock_engine.assert_called_once_with("postgresql+psycopg2://localhost:5432/test")