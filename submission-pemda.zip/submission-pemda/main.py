import sys
from utils import scrape_fashion, clean_data, load_data

def main():

    print("==================================================")
    print("   STARTING ETL PIPELINE - FASHION STUDIO CO.    ")
    print("==================================================")
    
    BASE_URL = 'https://fashion-studio.dicoding.dev/'
    print("\n[STEP 1] Menjalankan proses ekstraksi data produk...")
    raw_data = scrape_fashion(BASE_URL)
    
    if not raw_data:
        print("[ERROR] Pipeline dihentikan: Gagal mengekstrak data dari web target.")
        sys.exit(1)
        
    print("\n[STEP 2] Menjalankan proses transformasi data dengan Pandas...")
    try:
        df_clean = clean_data(raw_data)
        if df_clean.empty:
            print("[ERROR] Pipeline dihentikan: Hasil data bersih kosong.")
            sys.exit(1)
    except Exception as e:
        print(f"[CRITICAL ERROR] Kegagalan pada tahap transformasi: {e}")
        sys.exit(1)
        
    print("\n[STEP 3] Menjalankan proses pemuatan data ke repositori...")
    
    GOOGLE_SHEETS_URL = GOOGLE_SHEETS_URL = "https://docs.google.com/spreadsheets/d/1k9bYcZlgDkwpyZ1USNwzNpBIER3hd_BRNHC4fEisCh0/edit?usp=sharing"
    
    POSTGRES_DB_URL = "postgresql+psycopg2://developer:supersecretpassword@localhost:5432/fashion_db"
    
    try:
        load_data(df_clean, spreadsheet_url=GOOGLE_SHEETS_URL, db_url=POSTGRES_DB_URL)
        print("\n==================================================")
        print("   ETL PIPELINE SUCCESSFUL - ALL DATA LOADED!     ")
        print("==================================================")
    except Exception as e:
        print(f"[CRITICAL ERROR] Kegagalan pada tahap load data: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()