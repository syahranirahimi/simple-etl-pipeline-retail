import os
import pandas as pd
from sqlalchemy import create_engine
import gspread
from oauth2client.service_account import ServiceAccountCredentials

def load_data(df, spreadsheet_url, db_url):
    """
    Memuat data bersih (DataFrame) ke CSV, Google Sheets menggunakan ID Spreadsheet,
    dan PostgreSQL menggunakan db_url dari main.py.
    """
    if df.empty:
        print("[LOAD ERROR] Data kosong, proses pemuatan dibatalkan.")
        return False

    print("Memulai pemuatan data ke semua repositori...")

    try:
        csv_filename = "products.csv"
        df.to_csv(csv_filename, index=False)
        print(f"[LOAD] Berhasil menyimpan data ke flat file: {csv_filename}")
    except Exception as e:
        print(f"[LOAD ERROR] Gagal menyimpan ke CSV: {e}")

    try:
        scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
        credential_path = "google-sheets-api.json"
        
        if not os.path.exists(credential_path):
            raise FileNotFoundError(f"Berkas kredensial '{credential_path}' tidak ditemukan.")

        import json
        with open(credential_path, 'r') as f:
            creds_data = json.load(f)
            
        creds = ServiceAccountCredentials.from_json_keyfile_dict(creds_data, scope)
        client = gspread.authorize(creds)

        sheet_id = "1k9bYcZlgDkwpyZ1USNwzNpBIER3hd_BRNHC4fEisCh0"

        sheet_connection = client.open_by_key(sheet_id)
        sheet = sheet_connection.sheet1

        sheet.clear()

        data_to_upload = [df.columns.values.tolist()] + df.astype(str).values.tolist()

        sheet.update("A1", data_to_upload)
        print("[LOAD] Berhasil mengunggah dan memperbarui data di Google Sheets!")
        
    except Exception as e:
        print(f"[LOAD ERROR] Gagal memuat data ke Google Sheets: {type(e).__name__} - {e}")

    try:
        engine = create_engine(db_url)
        df.to_sql('fashion_products', engine, if_exists='replace', index=False)
        print("[LOAD] Berhasil memuat data ke database PostgreSQL (tabel: fashion_products)!")
    except Exception as e:
        print(f"[LOAD ERROR] Gagal memuat data ke PostgreSQL: {e}")

    return True