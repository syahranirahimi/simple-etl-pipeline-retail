from .extract import scrape_fashion
from .transform import clean_data
from .load import load_data