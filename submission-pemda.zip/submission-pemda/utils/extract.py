import requests
from bs4 import BeautifulSoup
import time

def scrape_fashion(base_url):
    all_products = []
    base_url = base_url.rstrip('/')
    
    print("Memulai ekstraksi data dari 50 halaman dengan URL asli...")
    
    for page in range(1, 51):
        if page == 1:
            url = base_url
        else:
            url = f"{base_url}/page{page}"
            
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            }
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code != 200:
                continue
                
            soup = BeautifulSoup(response.text, 'html.parser')
            products = soup.find_all('div', class_='collection-card')
            
            for product in products:
                title_elem = product.find('h3', class_='product-title')
                title = title_elem.text.strip() if title_elem else "Unknown Product"
                
                price_elem = product.find('span', class_='price')
                price = price_elem.text.strip() if price_elem else "Price Unavailable"
                
                rating = "Not Rated"
                colors = "1 Color"
                size = "M"
                gender = "Unisex"
                
                paragraphs = product.find_all('p')
                for p in paragraphs:
                    p_text = p.text.strip()
                    if 'Rating:' in p_text or '⭐' in p_text:
                        rating = p_text
                    elif 'Colors' in p_text or 'Color' in p_text:
                        colors = p_text
                    elif 'Size:' in p_text:
                        size = p_text
                    elif 'Gender:' in p_text:
                        gender = p_text

                all_products.append({
                    'Title': title,
                    'Price': price,
                    'Rating': rating,
                    'Colors': colors,
                    'Size': size,
                    'Gender': gender
                })
        except Exception as e:
            print(f"Gagal mengekstrak halaman {page}: {e}")
            
        time.sleep(0.01)
        
    return all_products