import pandas as pd
import numpy as np
import datetime

def clean_data(raw_data):
    df = pd.DataFrame(raw_data)
    
    if df.empty:
        return df

    mapping = {
        'title': 'Title', 'price': 'Price', 'rating': 'Rating',
        'colors': 'Colors', 'size': 'Size', 'gender': 'Gender'
    }
    df = df.rename(columns=str.lower).rename(columns=mapping)

    df = df[df['Title'].astype(str).str.strip().str.lower() != 'unknown product']

    df = df[~df['Price'].astype(str).str.contains('Price Unavailable', case=False, na=True)]
    df['Price'] = df['Price'].astype(str).str.replace(r'[^\d.]', '', regex=True)
    df['Price'] = pd.to_numeric(df['Price'], errors='coerce')
    df['Price'] = df['Price'] * 16000.0

    df = df[~df['Rating'].astype(str).str.contains('Invalid Rating|Not Rated', case=False, na=True)]
    df['Rating'] = df['Rating'].astype(str).str.replace('Rating:', '', case=False)
    df['Rating'] = df['Rating'].str.split('/').str[0]
    df['Rating'] = df['Rating'].str.extract(r'([\d.]+)')[0]
    df['Rating'] = pd.to_numeric(df['Rating'], errors='coerce')

    df['Colors'] = df['Colors'].astype(str).str.replace(r'[^\d]', '', regex=True)
    df['Colors'] = pd.to_numeric(df['Colors'], errors='coerce').fillna(1).astype(int)

    df['Size'] = df['Size'].astype(str).str.replace('Size:', '', case=False).str.strip()
    df['Gender'] = df['Gender'].astype(str).str.replace('Gender:', '', case=False).str.strip()

    df = df.dropna(subset=['Title', 'Price', 'Rating'])

    df = df.drop_duplicates()
    df = df.reset_index(drop=True)

    df['Timestamp'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    return df